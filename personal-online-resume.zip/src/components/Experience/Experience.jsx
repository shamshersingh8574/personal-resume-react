import React from 'react'
import "./experience.css";

const Experience = () => {
    return (
        <section className='experience' id='experience'>
                <div className='experience-main'>
                    <div className='experience-8'>
                        <p>8+</p>
                        <p>years</p>
                        <p>Experience</p>
                    </div>
                    <div className='experience-20'>
                        <p>20+</p>
                        <p>Completed</p>
                        <p>Projects</p>
                    </div>
                    <div className='experience-5'>
                        <p>5+</p>
                        <p>Companies</p>
                        <p>Work</p>
                    </div>
                </div>           
        </section>
    )
}

export default Experience