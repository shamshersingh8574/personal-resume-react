import React from 'react'

export const Toggle = () => {
  return (
    <div className='toggle'>
toggle
    </div>
  )
}
