import React from 'react'
import "./card.css";

const Card = ({ emoji, heading, detail }) => {
  return (
    <div className='services-card'>
      <img src={emoji} alt="" />
      <h3>{heading}</h3>
      <p>{detail}</p>
      <div className='service-card-btn'>
        <a href="#">Lean more</a>
      </div>
    </div>
  )
}

export default Card