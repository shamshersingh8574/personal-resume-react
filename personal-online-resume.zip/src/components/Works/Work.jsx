import React from 'react'
import amazon from "../../img/amazon.png";
import Shopify from "../../img/Shopify.png"
import Facebook from "../../img/Facebook.png"
import Upwork from "../../img/Upwork.png"
import fiverr from "../../img/fiverr.png"
import "./work.css";

const Work = () => {
  return (
    <section className='work' id='work'>
        <div className='work-main'>
          <div className='main-services-text'>
            <p>Works for All these</p>
            <p>Brands & Clients</p>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. A, officiis! Commodi fugiat explicabo eius animi recusandae officiis delectus quidem exercitationem, praesentium incidunt, eligendi laborum dolores, maiores beatae molestiae natus odio!</p>
            <div className='service-btn'>
              <a href="#">Hire me</a>
            </div>
          </div>
          <div className='work-img'>
            <div className='work-img-circle-1'></div>
            <div className='work-img-circle-2'></div>
            <div className='work-img-circle-3'></div>
            <div className='work-img-1'>
              <img src={amazon} alt="" />
            </div>
            <div className='work-img-2'>
              <img src={Shopify} alt="" />
            </div>
            <div className='work-img-3'>
              <img src={fiverr} alt="" />
            </div>
            <div className='work-img-4'>
              <img src={Facebook} alt="" />
            </div>
            <div className='work-img-5'>
              <img src={Upwork} alt="" />
            </div>
          </div>
        </div>
    </section>
  )
}

export default Work