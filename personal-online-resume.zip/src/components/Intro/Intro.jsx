import React from 'react'
import boy from '../../img/boy.png'
import Vector1 from '../../img/Vector1.png'
import Vector2 from '../../img/Vector2.png'
import crown from '../../img/crown.png'
import glassesimoji from '../../img/glassesimoji.png'
import thumbup from '../../img/thumbup.png'
import github from '../../img/github.png'
import linkedin from '../../img/linkedin.png'
import instagram from '../../img/instagram.png'
import { motion } from "framer-motion"
import "./intro.css"
import Floatingdiv from '../FloatingDiv/Floatingdiv'
import Experience from '../Experience/Experience'
import Services from '../Services/Services'
import Work from '../Works/Work'
import Portfolio from '../Portpolio/Portfolio'
import Testimonial from '../Testmonial/Testimonial'
import { NavLink, Outlet } from 'react-router-dom'

const Intro = () => {
  // const navigate = useNavigate();
  const nextpage = () => {


  }
  const transition = { duration: 2, type: 'spring' }
  return (
    <section className='banner' id='banner'>
      <div className='banner-main'>
        <div className='banner-text'>
          <p>Hy! I am</p>
          <p>Shamsher singh</p>
          <p>Front-end developer and Web Designer and better work in Live project</p>
          <div className='banner-text-btn'>
              {/* <a href="#">Hire me</a>  */}
              <NavLink to="floatingdiv">Campany</NavLink>              
              <Outlet/>

          </div>
          <div className='banner-text-img'>
            <a href="#"><img src={github} alt="" /></a>
            <a href="#"><img src={linkedin} alt="" /></a>
            <a href="#"><img src={instagram} alt="" /></a>

          </div>
        </div>
        <div className='banner-img'>
          <img src={Vector1} alt="" />
          <img src={Vector2} alt="" />
          <img src={boy} alt="" />
          <motion.img
            initial={{ left: '-36%' }}
            whileInView={{ left: '-24%' }}
            transition={transition}
            src={glassesimoji} alt=''
          />
          <motion.img
            initial={{ left: '-36%' }}
            whileInView={{ left: '-24%' }}
            transition={transition}
            src={thumbup} alt=''
          />
          {/* <img src={thumbup} alt="" /> */}

          <motion.img
            initial={{ top: '6% ', left: '74%' }}
            whileInView={{ left: '68%' }}
            transition={transition}
            style={{ top: "6%", left: "68%" }}
            src={crown} alt=''
          />
          {/* <img src={crown} alt="" /> */}
        </div>
      </div>
      
          <Services />
          <Experience />
          <Work />
          <Portfolio />
          <Testimonial />
    </section>
  )
}

export default Intro