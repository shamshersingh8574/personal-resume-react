import React from 'react'
import "./services.css";
import Card from '../Card/Card';
import heartemoji from '../../img/heartemoji.png'
import humble from '../../img/humble.png'
import glasses from '../../img/glasses.png'
import Resume from "./resume.pdf"
import { motion } from 'framer-motion';


const Services = () => {
    // transition
    const transition = {
        duration: 1,
        type: "spring",
    };
    return (
        <section className='services' id='services'>
            <div className='main-services'>
                <div className='main-services-text'>
                    <p>My Awesome</p>
                    <p>Services</p>
                    <p>Front-end developer and Web Designer and better work in Live project</p>
                    <div className='service-btn'>
                        <a href={Resume} download>Download CV</a>
                    </div>
                </div>
                <div className='main-services-card'>
                    <motion.div className='main-services-card-1'
                        initial={{ right: "25rem" }}
                        whileInView={{ left: "14rem" }}
                        transition={transition}
                    >

                        <Card
                            emoji={heartemoji}
                            heading={"Design"}
                            detail={"Figma, Sketch, Photoshop, Adove , Adove xd"}
                        />
                    </motion.div>

                    <motion.div className='main-services-card-2'
                        initial={{ left: "-11rem", top: "12rem" }}
                        whileInView={{ left: "-5rem" }}
                        transition={transition}
                    >
                        <Card
                            emoji={glasses}
                            heading={"Developer"}
                            detail={"HTML, CSS, Javascript, React , JQuery"}
                        />
                    </motion.div>

                    <motion.div className='main-services-card-3'
                        initial={{ top: "22rem", left: "25rem" }}
                        whileInView={{ left: "14rem" }}
                        transition={transition}>
                        <Card
                            emoji={humble}
                            heading={"UI / UX"}
                            detail={"HTML, CSS, Javascript, React , JQuery"}
                        />
                    </motion.div>
                </div>

            </div>
        </section>
    )
}

export default Services