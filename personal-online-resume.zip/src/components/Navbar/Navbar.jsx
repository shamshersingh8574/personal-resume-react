import React from 'react'
import "./navbar.css"
import { Toggle } from '../Toggle/Toggle';
import { Link } from 'react-scroll';

const Navbar = () => {
  return (
    <header className='header' id='header'>   
      <div className='navbar'>
        <div className='navbar-toggle'>
          <p>Andrew</p>
         <Toggle/>
        </div>
        <nav className='nav'>
          <ul>
           <Link spy={true} to='banner' smooth={false} activeClass='activeClass'>
          <li><a href='#'>Home</a></li>
          </Link>
          <Link spy={true} to='services' smooth={false} activeClass='activeClass'>
          <li><a href='#'>Services</a></li>
          </Link>
          <Link spy={true} to='experience' smooth={false} activeClass='activeClass'>
          <li><a href='#'>Experience</a></li>
          </Link>
          <Link spy={true} to='portfolio' smooth={false} activeClass='activeClass'>
          <li><a href='#'>Portfolio</a></li>
          </Link>
          <Link spy={true} to='testimonial' smooth={false} activeClass='activeClass'>
          <li><a href='#'>Testimonial</a></li>
          </Link>            
                   
          </ul>
        </nav>
        <div className='navbar-btn'><a href='#'>contact</a></div>
      </div>
     
    </header>
  )
}
export default Navbar;