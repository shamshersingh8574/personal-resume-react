import React from 'react'
import "./testimonial.css"
import profile1 from "../../img/profile1.jpg"
import profile2 from "../../img/profile2.jpg"
import profile3 from "../../img/profile3.jpg"
import profile4 from "../../img/profile4.jpg"
import profile5 from "../../img/profile5.jpg";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider from "react-slick";
const Testimonial = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2000
  };
  const clients = [
    {
      img: profile1,
      review:
        " Lorem ipsum dolor sit amet, Lorem ipsum dolor sit amet, Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eveniet atque, consequuntur aperiam iusto earum ratione? Quia quaerat voluptatem corporis assumenda tempore impedit libero labore ullam. Obcaecati saepe voluptates quidem a  ddd",
    },
    {
      img: profile2,
      review:
        " Lorem ipsum dolor sit amet, Lorem ipsum dolor sit amet, Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eveniet atque, consequuntur aperiam iusto earum ratione? Quia quaerat voluptatem corporis assumenda tempore impedit libero labore ullam. Obcaecati saepe voluptates quidem a  ddd",
    },
    {
      img: profile3,
      review:
        " Lorem ipsum dolor sit amet, Lorem ipsum dolor sit amet, Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eveniet atque, consequuntur aperiam iusto earum ratione? Quia quaerat voluptatem corporis assumenda tempore impedit libero labore ullam. Obcaecati saepe voluptates quidem a  ddd",
    },
    {
      img: profile4,
      review:
        " Lorem ipsum dolor sit amet, Lorem ipsum dolor sit amet, Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eveniet atque, consequuntur aperiam iusto earum ratione? Quia quaerat voluptatem corporis assumenda tempore impedit libero labore ullam. Obcaecati saepe voluptates quidem a  ddd",
    }
  ]
  return (
    <section className='testimonial' id='testimonial'>
        <div className='testimonial-main'>
          <div className='testimonial-slide'>
            <h2> Single Item</h2>
            <Slider {...settings}>
              {
                clients.map((clients, index) => {
                  return (

                    <div className='testimonial-slide-1'>
                      <div className='testimonial-slide-1-img'>
                        <img src={clients.img} alt="" />
                      </div>
                      <div className='testimonial-slide-1-text'>
                        <p>{clients.review}</p>
                      </div>
                    </div>

                  )
                })}

            </Slider>
          </div>
        </div>     
    </section>
  )
}

export default Testimonial