import React from 'react';
import {NavLink} from "react-router-dom"

const Floatingdiv = () => {
  
  return (
    <div>
      Lorem ipsum dolor, sit amet consectetur adipisicing elit. Mollitia dolor reiciendis earum pariatur, quas soluta autem aliquam voluptatibus fuga culpa praesentium, nihil tempora. Quibusdam accusamus maiores minus voluptates, optio quisquam, dolore error praesentium, ullam perferendis repudiandae totam nostrum tenetur sit reprehenderit. At rem ipsa animi maxime sapiente, nisi odio aliquid, perferendis quisquam, molestias officiis. Blanditiis nostrum voluptatibus autem excepturi a modi cum libero fugiat molestias hic officiis asperiores ratione, illo cumque, ab reiciendis ipsa dicta soluta possimus impedit explicabo quibusdam dolorem vero! Autem perferendis incidunt maiores, obcaecati hic temporibus voluptates dolores iure eaque at architecto commodi deleniti veniam in corrupti illo quod blanditiis magni quasi assumenda vero ut impedit repellendus? Quasi iusto, doloribus, maxime commodi fugiat, hic molestias nesciunt eligendi quidem laudantium illum natus aliquam itaque ducimus ex illo corporis minima labore voluptates molestiae aut accusamus impedit! Odit atque laboriosam veniam illum necessitatibus commodi ratione eum dolores perspiciatis voluptate. Nihil quod, blanditiis doloribus aspernatur reprehenderit veniam quis praesentium optio modi beatae sint exercitationem quos ullam eaque sit unde voluptate minima magnam? Praesentium eius corrupti perferendis beatae quo esse? Nisi fugit atque ex, culpa voluptates sit maiores corrupti nam alias ut aliquam impedit nulla aliquid! Expedita quidem commodi unde earum alias.
    <div>
      <NavLink to="/">back to home page</NavLink>
    </div>
    </div>
  )
}

export default Floatingdiv