import logo from './logo.svg';
import './App.css';
import Navbar from './components/Navbar/Navbar';
import Intro from './components/Intro/Intro';
import Services from './components/Services/Services';
import Experience from './components/Experience/Experience';
import Works from './components/Works/Work';
import Portfolio from './components/Portpolio/Portfolio';
import Testimonial from './components/Testmonial/Testimonial';
import Footer from './components/Footer/Footer';
import Floatingdiv from './components/FloatingDiv/Floatingdiv';
import { BrowserRouter, Route, Routes } from 'react-router-dom';

function App() {
  return (

    <div className="container">

      <BrowserRouter>
        <Navbar />
        <Routes>
         <Route path='/' element={<Intro/>} >
         <Route path='floatingdiv' element={<Floatingdiv/>}/>
         </Route>         
        
          {/* <Intro />
          <Services />
          <Experience />
          <Works />
          <Portfolio />
          <Testimonial /> */}
        </Routes>
        <Footer />
      </BrowserRouter>
    </div>

  );
}

export default App;
